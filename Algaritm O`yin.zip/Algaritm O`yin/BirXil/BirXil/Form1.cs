﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BirXil
{
    public partial class Form1 : Form
    {
        Image[] resmler =
        {
            Properties.Resources.Nodir,
            Properties.Resources.Tuya,
            Properties.Resources.Ronaldo,
            Properties.Resources.Mirjalol,
            Properties.Resources.Oyin,
            Properties.Resources.Koz,
            Properties.Resources.Yurak,
            Properties.Resources.Yoshlik

        };

        int[] indekslar = { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7 };
        PictureBox ilkkutu;
        int ilkIndeks, bulunan, deneme;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rasmlarKartinki();
        }

        private void rasmlarKartinki()
        {
            Random rnd = new Random();
            for(int i = 0; i<16; i++)
            {
                int sayi = rnd.Next(16);
                int gecici = indekslar[i];
                indekslar[i] = indekslar[sayi];
                indekslar[sayi] = gecici;
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            PictureBox kutu= (PictureBox)sender;
            int kutuNo = int.Parse(kutu.Name.Substring(10));
            int indeksNo = indekslar[kutuNo-1];    
            kutu.Image = resmler[indeksNo];
            kutu.Refresh();

            if (ilkkutu == null)
            {
                ilkkutu = kutu;
                ilkIndeks = indeksNo;
                deneme++;
            }
            else
            {
                System.Threading.Thread.Sleep(1500);
                ilkkutu.Image = null;
                kutu.Image = null;

                if (ilkIndeks == indeksNo)
                {
                    bulunan++;
                    ilkkutu.Visible = false;
                    kutu.Visible = false;

                    if (bulunan == 8)
                    {
                        MessageBox.Show("Tabriklayman" + deneme + "S da boldiz.");
                        bulunan = 0;
                        deneme = 0;

                        foreach (Control kontrol in Controls)
                        {
                            kontrol.Visible = true;
                        }
                        rasmlarKartinki();
                    }
                }
                ilkkutu = null;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {

        }
    }
}
